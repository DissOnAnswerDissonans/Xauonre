﻿using MiniXauonre.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
Banker
- Interest Rate: Все союзники в радиусе 10 восстонавливают (5 + 2%AP) 
		недостающего запаса здоровья,
	 а при повышении уровня получают (100%AP) MaxHp.
- Investment: Передает выбранному союзнику (5 + 10%AP) Money.
	 CD 8. Cost 30.
- Currency Exchange: Получает чистый урон равный (10 + 10%AP)%
	 MaxHp всех противников и получает за это опыт. CD 6. Cost 40.

Hp = 950
Armor = 15
Resist = 20
Energy = 100
ER = 5
AR = 10
MS = 10
    **/

namespace MiniXauonre.Core.Heroes
{
    class Banker : HeroWithBaseSkills
    {
        public const double InteresRateHeal = 0.05;
        public const double InterestRateHealAPScale = 0.02;
        public const double InterestRateHealRange = 10;
        public const double InterestRateHpBuffAPScale = 1;
        public Perk InterestRate { get; set; }

        public const double InvestmentMoney = 5;
        public const double InvestmentAPScale = 0.1;
        public const double InvestmentCD = 8;
        public const double InvestmentCost = 30;
        public Skill Investment { get; set; }

        public const double ExchangeHP = 0.1;
        public const double ExchangeAPScale = 0.1;
        public const double ExchangeCD = 6;
        public const double ExchangeCost = 40;
        public Skill CurrencyExchange { get; set; }

        public Banker()
        {
            Name = "Banker";
            SetMaxHp(950);
            SetArmor(15);
            SetResist(20);
            SetMaxEnergy(100);
            SetEnergyRegen(5);
            SetMovementSpeed(10);
            SetAttackRange(10);


            InterestRate = new Perk
            {
                LevelUp = (a) => (d) =>
                {
                    var hpBuff = GetAbilityPower() * InterestRateHpBuffAPScale;
                    foreach (var h in P.Heroes)
                    {
                        h.AddMaxHp(hpBuff);
                        h.AddHp(hpBuff);
                    }
                    return d;
                },

                EndTurn = (a) => (d) =>
                {
                    var targets = GetHeroesInRange(M, InterestRateHealRange).Where(h => P.Heroes.Contains(h));
                    foreach (var ally in targets)
                        ally.AddHp((ally.GetMaxHp() - ally.GetHp()) * (InteresRateHeal + InterestRateHealAPScale * GetAbilityPower()));
                    return d;
                },
            };
            Perks.Add(InterestRate);

            Investment = new Skill
            {
                Name = "Investment",
                Explanation = () => "Give chosen ally up to " + InvestmentMoney + " + " + InvestmentAPScale * 100 + "%AP ("
                    + (InvestmentMoney + GetAbilityPower() + InvestmentAPScale)*GetMaxHp() + ") Money from yours."
                    + " CD " + InvestmentCD + "(" + Investment.Timer + "). Cost " + InvestmentCost + ".",
                CoolDown = InvestmentCD,
                EnergyCost = InvestmentCost,
                Job = (h) =>
                {
                    var moneyNeed = InvestmentMoney + GetAbilityPower() + InvestmentAPScale;
                    if (GetMoney() < moneyNeed)
                        moneyNeed = GetMoney();
                    Target = ChooseTarget(P.Heroes.Where(s => s != this).ToList(), P);
                    Target.AddMoney(moneyNeed);
                    AddMoney(-moneyNeed);
                    return true;
                }
            };
            Investment.SkillTypes.Add(SkillType.Special);
            Skills.Add(Investment);


            CurrencyExchange = new Skill
            {
                Name = "Currency Exchange",
                Explanation = () => "Gets "+
                ExchangeHP +" + "+ ExchangeAPScale * 100 +"%AP ("+
                (ExchangeHP + ExchangeAPScale*GetAbilityPower())+") Pure damage and get EXP for it. Cooldown "+ExchangeCD+". Cost "+ExchangeCost+".",
                CoolDown = ExchangeCD,
                EnergyCost = ExchangeCost,
                Job = (h) =>
                {
                    var damage = new Damage(h, P, pure: (ExchangeHP + ExchangeAPScale * GetAbilityPower())*GetMaxHp());
                    var was = GetHp();
                    GetDamage(damage);
                    var became = GetHp();
                    P.AllDamage += (was - became);
                    return true;
                },

            };
            CurrencyExchange.SkillTypes.Add(SkillType.Special);
            Skills.Add(CurrencyExchange);
        }
    }
}
