﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniXauonre.Core.Items
{
    class Razor : Item
    {
        public Razor()
        {
            Name = "Razor";
            Cost = 70;
            AD = 7;

        }
    }
}
